﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq
{
    public static class ExMethod
    {
        public static string Lesenka(this string str, int number = 0)
        {
            string res = string.Empty;
            for(int i=0; i<str.Length; i++)
            {
                if (i < number)
                {
                    res += str[i];
                }
                else
                {
                    if (i % 2 == 0)
                    {
                        res += str[i].ToString().ToUpper();
                    }
                    else
                    {
                        res += str[i];
                    }
                }
            }
            return res;
        }
    }
}
