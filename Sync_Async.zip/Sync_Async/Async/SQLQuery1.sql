﻿CREATE TABLE Jenres
(	
	id INT NOT NULL PRIMARY KEY IDENTITY (1,1),
	Name NVARCHAR (50)
);
CREATE TABLE Movies
(
	id INT NOT NULL PRIMARY KEY IDENTITY (1,1),
	Name NVARCHAR (50),
	Id_Janre INT NOT NULL FOREIGN KEY REFERENCES Jenres(id)
);
INSERT INTO Jenres (Name) VALUES (N'Comedy');
INSERT INTO Jenres (Name) VALUES (N'Боевик');
INSERT INTO Jenres (Name) VALUES (N'Фентези');
INSERT INTO Jenres (Name) VALUES (N'Мелодрамма');
INSERT INTO Jenres (Name) VALUES (N'Ужасы');

SELECT * FROM Jenres;

INSERT INTO Movies (Name, Id_Janre) VALUES (
	N'Брильянтовая рука',
	(SELECT id FROM Jenres WHERE Name=N'Comedy'));

INSERT INTO Movies (Name, Id_Janre) VALUES (
	N'Пятый элемент',
	(SELECT id FROM Jenres WHERE Name=N'Боевик'));

INSERT INTO Movies (Name, Id_Janre) VALUES (
	N'Москва слезам не верит',
	(SELECT id FROM Jenres WHERE Name=N'Мелодрамма'));

INSERT INTO Movies (Name, Id_Janre) VALUES (
	N'Большая прогулка',
	(SELECT id FROM Jenres WHERE Name=N'Comedy'));

INSERT INTO Movies (Name, Id_Janre) VALUES (
	N'Аватар',
	(SELECT id FROM Jenres WHERE Name=N'Фентези'));

SELECT Movies.Name AS Фильм, Jenres.Name AS Жанр
FROM Movies INNER JOIN Jenres ON Movies.Id_Janre=Jenres.id;
