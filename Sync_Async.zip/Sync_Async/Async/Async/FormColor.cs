﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;

namespace Async
{
    public class FormColor
    {
        public Color Color { set; get; }
        public string Text { set; get; }
        public override string ToString()
        {
            return Text;
        }
    }

}
