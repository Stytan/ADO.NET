﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Async
{
    public partial class Form1 : Form
    {
        public string _conString;
        public Form1()
        {
            InitializeComponent();
        }
        private void ComboBoxLoader(ToolStripComboBox comboBox)
        {
            comboBox.Items.Add(new FormColor { Color = this.BackColor, Text = "Default" });
            comboBox.Items.Add(new FormColor { Color = Color.Red, Text = "Red" });
            comboBox.Items.Add(new FormColor { Color = Color.Green, Text = "Green" });
            comboBox.Items.Add(new FormColor { Color = Color.Blue, Text = "Blue" });
            comboBox.SelectedIndex = 0;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ComboBoxLoader(toolStripComboBox1);
            ComboBoxLoader(toolStripComboBox2);
            _conString = ConfigurationManager.ConnectionStrings["Cinema"].ConnectionString;
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            BackColor = ((FormColor)toolStripComboBox1.SelectedItem).Color;
            //if(toolStripComboBox2.SelectedIndex != toolStripComboBox1.SelectedIndex)
            //    toolStripComboBox2.SelectedIndex = toolStripComboBox1.SelectedIndex;
        }
        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            BackColor = ((FormColor)toolStripComboBox2.SelectedItem).Color;
            //if(toolStripComboBox1.SelectedIndex != toolStripComboBox2.SelectedIndex)
            //    toolStripComboBox1.SelectedIndex = toolStripComboBox2.SelectedIndex;
        }
        private void SyncMenu_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection { ConnectionString = _conString };
            SqlDataReader reader = null;
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand
                {
                    CommandText = "WAITFOR DELAY '0:0:5'; SELECT Movies.Name AS Фильм, Jenres.Name AS Жанр FROM Movies INNER JOIN Jenres ON Movies.Id_Janre = Jenres.id; ",
                    Connection = conn
                };
                reader = command.ExecuteReader();
                List<Movie> movies = new List<Movie>();
                while (reader.Read())
                {
                    movies.Add(
                        new Movie
                        {
                            Name = reader.GetString(0),
                            Janre = reader.GetString(1)
                        });
                }
                dataGridView1.DataSource = movies;
                Text = "Синхронный код выполнен";
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                reader.Close();
                conn.Close();
            }
        }

        private void beginEndMenu_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Id callback thread: " + Thread.CurrentThread.ManagedThreadId);
            SqlConnection conn = new SqlConnection { ConnectionString = _conString };
            conn.Open();
            SqlCommand command = new SqlCommand
            {
                CommandText = "WAITFOR DELAY '0:0:5'; SELECT Movies.Name AS Фильм, Jenres.Name AS Жанр FROM Movies INNER JOIN Jenres ON Movies.Id_Janre = Jenres.id; ",
                Connection = conn
            };
            Text = "Выполняется асинхронный вызов";
            CommandHelper commandHelper = new CommandHelper { _command = command, _conn = conn };
            //command.BeginExecuteReader(callback, commandHelper);
            command.BeginExecuteReader(ar =>
            {
                Console.WriteLine("Id callback thread: " + Thread.CurrentThread.ManagedThreadId);
                SqlDataReader reader = null;
                try
                {
                    SqlCommand command2 = ((CommandHelper)ar.AsyncState)._command;
                    reader = command2.EndExecuteReader(ar);
                    List<Movie> movies = new List<Movie>();
                    while (reader.Read())
                    {
                        movies.Add(
                            new Movie
                            {
                                Name = reader.GetString(0),
                                Janre = reader.GetString(1)
                            });
                    }
                    /*
                    dataGridView1.DataSource = movies;
                    Text = "Асинхронный вызов выполнен";
                    */
                    //Используем лямбда-функцию для передачи действия

                    //ViewHelper(dataGridView1, () => dataGridView1.DataSource = movies);
                    //ViewHelper(this, () => Text = "Асинхронный вызов выполнен");
                    //или
                    dataGridView1.Interaction(() => dataGridView1.DataSource = movies);
                    dataGridView1.Interaction(() => dataGridView1.BackgroundColor = Color.Red);
                    this.Interaction(() => Text = "Асинхронный вызов выполнен");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    reader.Close();
                    ((CommandHelper)ar.AsyncState)._conn.Close();
                }
            }, commandHelper);
        }


        //private void callback(IAsyncResult ar)
        //{
        //    Console.WriteLine("Id callback thread: " + Thread.CurrentThread.ManagedThreadId);
        //    SqlDataReader reader = null;
        //    try
        //    {
        //        SqlCommand command = ((CommandHelper)ar.AsyncState)._command;
        //        reader = command.EndExecuteReader(ar);
        //        List<Movie> movies = new List<Movie>();
        //        while (reader.Read())
        //        {
        //            movies.Add(
        //                new Movie
        //                {
        //                    Name = reader.GetString(0),
        //                    Janre = reader.GetString(1)
        //                });
        //        }
        //        /*
        //        dataGridView1.DataSource = movies;
        //        Text = "Асинхронный вызов выполнен";
        //        */
        //        //Используем лямбда-функцию для передачи действия
        //        ViewHelper(dataGridView1, () => dataGridView1.DataSource = movies);
        //        ViewHelper(this, () => Text = "Асинхронный вызов выполнен");

        //        //Создание обобщенного делегата Action
        //        /*
        //         * Action<int, string> action1 = method1;
        //         * вызов
        //         * action1(2,"world");
        //         * где 
        //         * void method1(int i, string s) ();
        //         * */
        //         /*Делегат Func который можеь возвращать значение
        //          * последний тип параместра - это тип возвращаемого значения
        //          * Func<int, string, double> func1 = method2;
        //          * где
        //          * double method2(int i, string s) {return 5.5;}
        //          * вызов
        //          * double d = func1(5, "world");
        //          * */
        //          /*
        //           * Лямбда
        //           * double arg1, arg2;
        //           * double res = (arg1, arg2) => { return arg1 + arg2; };
        //           * 
        //           * Анонимный метод
        //           * delegate (double arg1, double arg2) {return arg1+arg2;}
        //           * */
        //    }
        //    catch (SqlException ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //    finally
        //    {
        //        reader.Close();
        //        ((CommandHelper)ar.AsyncState)._conn.Close();
        //    }
        //}
        private void ViewHelper(Control control, Action action)
        {
            //Каждый Control имеест свойство которое показывает
            //в этом ли потоке он создан
            //если он создан в другом потоке,
            //то вызывается действие через Invoke
            if (control.InvokeRequired)
            {
                control.Invoke(action);
            }
            else
            {
                action();
            }
        }
        /// <summary>
        /// Асинхронные вызовы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void asyncAwaitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Id callback thread: " + Thread.CurrentThread.ManagedThreadId);
            SqlConnection conn = new SqlConnection { ConnectionString = _conString };
            SqlDataReader reader = null;
            try
            {
                await conn.OpenAsync();
                SqlCommand command = new SqlCommand
                {
                    CommandText = "WAITFOR DELAY '0:0:5'; SELECT Movies.Name AS Фильм, Jenres.Name AS Жанр FROM Movies INNER JOIN Jenres ON Movies.Id_Janre = Jenres.id; ",
                    Connection = conn
                };
                reader = await command.ExecuteReaderAsync();

                List<Movie> movies = new List<Movie>();
                while (reader.Read())
                {
                    movies.Add(
                        new Movie
                        {
                            Name = reader.GetString(0),
                            Janre = reader.GetString(1)
                        });
                }
                dataGridView1.DataSource = movies;
                dataGridView1.BackgroundColor = Color.Blue;
                Text = "Await async выполнен";
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                reader.Close();
                conn.Close();
            }
        }
    }
}
