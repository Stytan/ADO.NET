﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Async
{
    public class Movie
    {
        public string Name { set; get; }
        public string Janre { set; get; }
    }
}
