﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Async
{
    public class CommandHelper
    {
        public SqlCommand _command { set; get; }
        public SqlConnection _conn { set; get; }
    }
}
